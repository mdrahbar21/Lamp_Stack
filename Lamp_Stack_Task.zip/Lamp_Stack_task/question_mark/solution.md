# Details

Rename this file in the format `yourRollNumber_solution.md` (example, `220000_solution.md`) and create a pull request in the parent repository on github.


## Your zeroth approach below

Reasoning - %%% Type your approach here %%%

```
%%% Replace this with the 0th challenge answer %%%
```

---

## Your first approach below (first.txt)

Reasoning - %%% Type your approach here %%%

```
%%% Replace this with the 1st challenge answer %%%
```

---

## Your second approach below (strings.txt)

Reasoning - %%% Type your approach here %%%

```
%%% Replace this with the 2nd challenge answer %%%
```

---

## Your third approach below (fourth.zip)

Reasoning - %%% Type your approach here %%%

```
%%% Replace this with the 3rd challenge answer %%%
```

---


- Name :
- Roll :
- GitHub username:
- Discord username:


## Do not tamper below this line

---

Q29yZSB0ZWFtIGtvIGZha2UgZG8=
